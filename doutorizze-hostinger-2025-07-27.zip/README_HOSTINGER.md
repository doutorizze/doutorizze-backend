# 🚀 DEPLOY DOUTORIZZE - HOSTINGER

## 📋 Instruções de Upload

### 1. Preparação dos Arquivos
✅ **Build concluído com sucesso!**
- Pasta `dist` contém todos os arquivos otimizados
- Arquivo `.htaccess` configurado para Hostinger
- Assets comprimidos e otimizados

### 2. Upload para Hostinger

#### Via File Manager (Recomendado)
1. **Acesse o hPanel da Hostinger**
2. **Vá em "File Manager"**
3. **Navegue até a pasta `public_html`**
4. **Faça upload de TODOS os arquivos da pasta `dist`:**
   - `index.html`
   - `.htaccess`
   - `favicon.svg`
   - `clinica.jpg`
   - Pasta `assets/` (completa)

#### Via FTP
1. **Use um cliente FTP (FileZilla, WinSCP)**
2. **Conecte com suas credenciais da Hostinger**
3. **Navegue até `/public_html`**
4. **Faça upload de todos os arquivos da pasta `dist`**

### 3. Configurações Importantes

#### Estrutura Final no Servidor:
```
public_html/
├── index.html
├── .htaccess
├── favicon.svg
├── clinica.jpg
└── assets/
    ├── index-KDEQL05H.css
    ├── index-CEWqfzpZ.js
    └── index-CIeJ5fu8.js
```

#### Configuração do Backend
- **Backend está rodando no Render:** `https://doutorizze-backend.onrender.com`
- **API já configurada no frontend**
- **CORS configurado para aceitar requisições do seu domínio**

### 4. Verificações Pós-Deploy

#### ✅ Checklist:
- [ ] Site carrega corretamente
- [ ] Roteamento SPA funciona (navegação entre páginas)
- [ ] Assets carregam sem erro 404
- [ ] API conecta com o backend
- [ ] Formulários funcionam
- [ ] Imagens carregam corretamente

#### 🔧 Testes:
1. **Acesse seu domínio**
2. **Teste navegação:** `/`, `/login`, `/register`, `/clinicas`
3. **Abra DevTools (F12)** e verifique:
   - Console sem erros
   - Network tab mostra status 200 para assets
   - API calls retornam dados

### 5. Configurações Adicionais

#### SSL/HTTPS
- **Ative SSL gratuito no hPanel da Hostinger**
- **Force HTTPS redirect** (já configurado no .htaccess)

#### Domínio Personalizado
- **Configure seu domínio no hPanel**
- **Atualize DNS se necessário**
- **Aguarde propagação (até 24h)**

### 6. Otimizações Aplicadas

#### Performance:
- ✅ Compressão GZIP ativada
- ✅ Cache de assets (30 dias)
- ✅ Headers de segurança
- ✅ Preload de recursos críticos

#### SEO:
- ✅ Meta tags configuradas
- ✅ Sitemap disponível
- ✅ Estrutura semântica

### 7. Troubleshooting

#### Problema: Página em branco
**Solução:** Verifique se o `.htaccess` foi enviado corretamente

#### Problema: Erro 404 em rotas
**Solução:** Confirme que o mod_rewrite está ativo na Hostinger

#### Problema: Assets não carregam
**Solução:** Verifique se a pasta `assets` foi enviada completamente

#### Problema: API não conecta
**Solução:** Verifique se o backend no Render está ativo

### 8. Suporte

#### Logs de Erro:
- **Hostinger:** hPanel > Error Logs
- **Backend:** Render Dashboard > Logs

#### Contatos:
- **Hostinger Support:** Via hPanel
- **Render Support:** Via Dashboard

---

## 🎉 Parabéns!

Seu sistema DOUTORIZZE está pronto para produção na Hostinger!

**URLs importantes:**
- **Frontend:** Seu domínio da Hostinger
- **Backend:** https://doutorizze-backend.onrender.com
- **API Health:** https://doutorizze-backend.onrender.com/api/health

**Data do Build:** $(date)
**Versão:** 1.0.0
**Ambiente:** Produção - Hostinger